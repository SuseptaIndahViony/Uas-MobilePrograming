import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tanaman_herbal/card_widget.dart';
import 'package:tanaman_herbal/tanaman.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CollectionReference<Tanaman> dataTanaman = FirebaseFirestore.instance
        .collection("tanaman")
        .withConverter<Tanaman>(
          fromFirestore: (snapshots, _) => Tanaman.fromJson(snapshots.data()!),
          toFirestore: (tanaman, _) => tanaman.toJson(),
        );

    return Scaffold(
      appBar: AppBar(
        title: Text("Tanaman Herbal"),
      ),
      body: StreamBuilder<QuerySnapshot<Tanaman>>(
        stream: dataTanaman.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }

          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          return GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
            ),
            itemCount: snapshot.data!.size,
            itemBuilder: (BuildContext ctx, index) {
              return CardWidget(
                docId: snapshot.data!.docs[index].id,
                image: snapshot.data!.docs[index]["gambar"],
                namaLokal: snapshot.data!.docs[index]["namaLokal"],
                namaLatin: snapshot.data!.docs[index]["namaLatin"],
                deskripsi: snapshot.data!.docs[index]["deskripsi"]
                    .replaceAll("\\n", "\n"),
                manfaat: snapshot.data!.docs[index]["manfaat"]
                    .replaceAll("\\n", "\n"),
              );
            },
          );
        },
      ),
    );
  }
}
