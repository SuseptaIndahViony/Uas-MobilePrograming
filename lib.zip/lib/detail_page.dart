import 'package:flutter/material.dart';
import 'package:tanaman_herbal/edit_page.dart';

class DetailPage extends StatelessWidget {
  final String docId;
  final String image;
  final String namaLokal;
  final String namaLatin;
  final String deskripsi;
  final String manfaat;
  const DetailPage({
    Key? key,
    required this.docId,
    required this.image,
    required this.namaLokal,
    required this.namaLatin,
    required this.deskripsi,
    required this.manfaat,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Tanaman Herbal"),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditPage(
                    docId: docId,
                    namaLokal: namaLokal,
                    namaLatin: namaLatin,
                    deskripsi: deskripsi,
                    manfaat: manfaat,
                  ),
                ),
              );
            },
            icon: Icon(
              Icons.edit,
            ),
          ),
        ],
      ),
      body: ListView(
        children: [
          Image.network(
            image,
            width: double.infinity,
            height: 250,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  namaLokal,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  namaLatin,
                  style: TextStyle(
                    color: Colors.black,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Text(
                  "Deskripsi",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
                Text(
                  deskripsi,
                  style: TextStyle(
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.justify,
                ),
                SizedBox(
                  height: 16,
                ),
                Text(
                  "Manfaat",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
                Text(
                  manfaat,
                  style: TextStyle(
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.justify,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
