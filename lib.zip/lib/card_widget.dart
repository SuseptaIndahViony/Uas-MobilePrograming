import 'package:flutter/material.dart';
import 'package:tanaman_herbal/detail_page.dart';

class CardWidget extends StatelessWidget {
  final String docId;
  final String image;
  final String namaLokal;
  final String namaLatin;
  final String deskripsi;
  final String manfaat;
  const CardWidget({
    Key? key,
    required this.docId,
    required this.image,
    required this.namaLokal,
    required this.namaLatin,
    required this.deskripsi,
    required this.manfaat,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DetailPage(
                docId: docId,
                image: image,
                namaLokal: namaLokal,
                namaLatin: namaLatin,
                deskripsi: deskripsi,
                manfaat: manfaat,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Image.network(
                image,
                width: double.infinity,
                height: 140,
                fit: BoxFit.cover,
              ),
              SizedBox(
                height: 8,
              ),
              Text(
                namaLokal,
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                namaLatin,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 10,
                  fontStyle: FontStyle.italic,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
