class Tanaman {
  final String docId;
  final String namaLokal;
  final String namaLatin;
  final String deskripsi;
  final String manfaat;
  final String gambar;

  Tanaman({
    required this.docId,
    required this.namaLokal,
    required this.namaLatin,
    required this.deskripsi,
    required this.manfaat,
    required this.gambar,
  });

  Tanaman.fromJson(Map<String, Object?> json)
      : this(
          docId: json["docId"] as String,
          namaLokal: json["namaLokal"] as String,
          namaLatin: json["namaLatin"] as String,
          deskripsi: json["deskripsi"] as String,
          manfaat: json["manfaat"] as String,
          gambar: json["gambar"] as String,
        );

  Map<String, Object?> toJson() {
    return {
      "docId": docId,
      "namaLokal": namaLokal,
      "namaLatin": namaLatin,
      "deskripsi": deskripsi,
      "manfaat": manfaat,
      "gambar": gambar,
    };
  }
}
