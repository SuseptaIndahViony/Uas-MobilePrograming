import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tanaman_herbal/home_page.dart';

class EditPage extends StatefulWidget {
  final String docId;
  final String namaLokal;
  final String namaLatin;
  final String deskripsi;
  final String manfaat;
  const EditPage({
    Key? key,
    required this.docId,
    required this.namaLokal,
    required this.namaLatin,
    required this.deskripsi,
    required this.manfaat,
  }) : super(key: key);

  @override
  State<EditPage> createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  TextEditingController textNamaLokalController = TextEditingController();
  TextEditingController textNamaLatinController = TextEditingController();
  TextEditingController textDeskripsiController = TextEditingController();
  TextEditingController textManfaatController = TextEditingController();

  @override
  void initState() {
    textNamaLokalController.text = widget.namaLokal;
    textNamaLatinController.text = widget.namaLatin;
    textDeskripsiController.text = widget.deskripsi;
    textManfaatController.text = widget.manfaat;
    super.initState();
  }

  Future<void> update() async {
    try {
      CollectionReference collectionReference =
          FirebaseFirestore.instance.collection('tanaman');

      collectionReference.doc(widget.docId).update({
        'namaLokal': textNamaLokalController.text,
        'namaLatin': textNamaLatinController.text,
        'deskripsi': textDeskripsiController.text,
        'manfaat': textManfaatController.text,
      }).then((value) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HomePage(),
          ),
        );

        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Done'),
              content: Text('Update Success'),
              actions: <Widget>[
                ElevatedButton(
                  child: Text('Oke'),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            );
          },
        );
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Tanaman Herbal"),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            "Nama Lokal",
            style: TextStyle(
              color: Colors.black,
              fontSize: 12,
            ),
          ),
          TextFormField(
            controller: textNamaLokalController,
            keyboardType: TextInputType.text,
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "Nama Latin",
            style: TextStyle(
              color: Colors.black,
              fontSize: 12,
            ),
          ),
          TextFormField(
            controller: textNamaLatinController,
            keyboardType: TextInputType.text,
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "Deskripsi",
            style: TextStyle(
              color: Colors.black,
              fontSize: 12,
            ),
          ),
          TextFormField(
            controller: textDeskripsiController,
            keyboardType: TextInputType.multiline,
            maxLines: 5,
            maxLength: 1000,
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "Manfaat",
            style: TextStyle(
              color: Colors.black,
              fontSize: 12,
            ),
          ),
          TextFormField(
            controller: textManfaatController,
            keyboardType: TextInputType.multiline,
            maxLines: 5,
            maxLength: 1000,
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
            onPressed: () {
              FocusScopeNode currentFocus = FocusScope.of(context);

              if (!currentFocus.hasPrimaryFocus) {
                currentFocus.unfocus();
              }

              update();
            },
            child: Text("Simpan Data"),
          ),
        ],
      ),
    );
  }
}
